create definer = root@localhost trigger set_applied_status
    before insert
    on vehicles_in
    for each row
BEGIN
    DECLARE exists_in_applied INT;

    SELECT COUNT(*) INTO exists_in_applied
    FROM applied_vehicles
    WHERE license_plate_number = NEW.license_plate_number;

    SET NEW.applied = (exists_in_applied > 0);
END;

