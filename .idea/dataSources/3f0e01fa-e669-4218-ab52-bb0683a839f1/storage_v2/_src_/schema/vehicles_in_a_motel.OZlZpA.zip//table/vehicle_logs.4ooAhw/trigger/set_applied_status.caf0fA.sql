create definer = root@localhost trigger set_applied_status
    before insert
    on vehicle_logs
    for each row
BEGIN
    DECLARE exists_in_applied INT;

    SELECT COUNT(*) INTO exists_in_applied
    FROM applied_vehicles
    WHERE license_plate_number = NEW.license_plate_number;

    SET NEW.applied = (exists_in_applied > 0);
END;

